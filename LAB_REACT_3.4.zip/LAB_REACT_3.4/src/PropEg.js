import React from 'react';

// import ReactDOM from 'react-dom';

import PropTypes from 'prop-types';
class PropEg extends React.Component {
  render() {
	return(
		<div>
			{
				this.props.prod.map(child =>
					{
						return(
							<div>
								<h3>{child.mName}</h3>
								<h3>{child.mTicket}</h3>
								<img src={child.mImg} height="400px" width="400px" />
							</div>
						);		
					})
			}
		</div>
	);   
  }
}
PropEg.propTypes = {
Movie: PropTypes.arrayOf(PropTypes.shape({
	mTicket: PropTypes.number.isRequired
}))
}
export default PropEg;


