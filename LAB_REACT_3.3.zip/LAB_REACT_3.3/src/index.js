import React from 'react';

import ReactDOM from 'react-dom';

import Parent from './Parent';


class App extends React.Component {
  render() {
	const childArr = ['ranjith','nava','saidutt','rahul','srikar','sagar'];
return(
		<div>
			{childArr.map((child, index)=>
			<h3>
				<h4>{child}</h4>
					
			
				<br/> 
				<h5> The length of the string is : {child.length}  
			
				<br/>
				The index of the element is : {index} 
				</h5>
			</h3>
			)}
				<br/>
				The length of the array is : {childArr.length}
		</div>
	);
  }
}
ReactDOM.render(<App />, document.getElementById('root'));





