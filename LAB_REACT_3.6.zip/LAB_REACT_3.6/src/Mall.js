import React from 'react';
import Theatre from './Theatre';
import ThemeContext from './ThemeContext';
import Screen from './Screen.js';
import Timings from './Timings.js';


class Mall extends React.Component {
  render() {
    return (
      <div>
        <ThemeContext.Provider value={this.props.movie}>
          <Theatre />
          <Screen/>
          <Timings />
        </ThemeContext.Provider>
        
      </div>

    )
  }
}
export default Mall;


