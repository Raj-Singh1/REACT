import React from 'react';

import ReactDOM from 'react-dom';

import Mall from './Mall';

var movies = [{
    tName : "INOX",
    tScreen : ["Tiger","Cheetah","Lion"],
    tTime : ["9 PM","5 PM","1 PM"]
}]

ReactDOM.render(<Mall movie={movies}/>, document.getElementById('root'));

