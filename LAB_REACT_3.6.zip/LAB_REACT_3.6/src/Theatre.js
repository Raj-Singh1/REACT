import React from 'react';
import ThemeContext from './ThemeContext';




// Context lets us pass a value deep into the component tree
// without explicitly threading it through every component.
// Create a context for the current theme (with "light" as the default).


class Theatre extends React.Component {
  
  render() {

    return (
      <div>
        <ThemeContext.Consumer>
          {(theatreName) => {
            return (
              <div>
                {/* <h4>{theatreName.tName}</h4> */}
                {theatreName.map((movie,index)=> <h3 key = {index}>
                Theatre Name : &nbsp;
                {movie.tName}</h3>)}
              </div>
            )
            }
          }
        </ThemeContext.Consumer>
      </div>
    )
  }
}
export default Theatre;


