import React from 'react';
import ThemeContext from './ThemeContext';
class Timings extends React.Component {

    render() {
        return (
          <div>
            <ThemeContext.Consumer>
              {(theatreName) => {
                return (
                  <div>
                    {theatreName.map((movie,index)=> 
                    <h4>
                      Timings :
                      <br/>
                      {movie.tTime.map((child, index)=>{
                        return <li key={index}>{child}</li>
                      })}
                    </h4>
                    )}
                  </div>
                )
                }
              }
            </ThemeContext.Consumer>
          </div>
        );
      }
}

export default Timings;