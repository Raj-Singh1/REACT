import React from 'react';

// import ReactDOM from 'react-dom';

import ThemeContext from './ThemeContext';

class Screen extends React.Component {
  render() {
    return (
      <div>
        <ThemeContext.Consumer>
          {(theatreName) => {
            return (
              <div>
                {theatreName.map((movie,index)=> 
                <h4>
                  Screen Name :
                  <br/>
                  {movie.tScreen.map((child, index)=>{
                    return <li key={index}>{child}</li>
                  })}
                </h4>
                )}
              </div>
            )
            }
          }
        </ThemeContext.Consumer>
      </div>
    );
  }
}
export default Screen;


