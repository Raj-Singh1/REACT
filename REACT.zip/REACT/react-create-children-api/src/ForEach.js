import React from 'react';

class Loop extends React.Component{
    render()
    {
        const arr=['sagar','dabang','kuku','ranjitey','bachcha'];
        return (
            <div>
                {arr.forEach((child,index)=>(
                <h3>{document.write("<br>"+child+"<br/> String Length : "+child.length+"<br/> Index of element : "+index+"<br><br>")}
                <br/>
                </h3>))}
                Array Length : {arr.length}                
            </div>
        )
    }
}

export default Loop;