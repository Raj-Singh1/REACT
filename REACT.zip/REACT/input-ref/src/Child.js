import React from 'react';
import GrandChild from './GrandChild';

class Child extends React.Component {

    constructor() {
        super();
        console.log("constructor");
    }

    // componentWillMount() {
    //     console.log("component will mount");
    // }

    // componentDidMount() {
    //     console.log("component did mount");
    // }

    // componentWillReceiveProps() {
    //     console.log("componentWillReceiveProps");
    // }

    // componentDidUpdate() {
    //     console.log("componentDidUpdate");
    // }

    // componentWillUnmount() {
    //     console.log("componentWillUnmount");
    // }

    // shouldComponentUpdate() {
    //     console.log("shouldComponentUpdate");
    //    var user=prompt("true or false");
    //    if(user === "true")
    //    {
    //     return true;
    //    }
    //    else
    //    {
    //        return false;
    //    }
    // }

    // componentWillUpdate() {
    //     console.log("componentWillUpdate");
    // }

    // componentDidCatch() {
    //     console.log('componentDidCatch')
    // }

    // render() {
    //     console.log("render");
    //     return (
    //         <div>
    //             Company Name from Child:- {this.props.companyName}
    //             <GrandChild companyName={this.props.companyName} />
    //         </div>
    //     )
    // }

    //---------------USING REST FUNCTION------------//
    
    componentWillMount(...args) {
        console.log("component will mount",args);
    }

    componentDidMount(...args) {
        console.log("component did mount",args);
    }

    componentWillReceiveProps(...args) {
        console.log("componentWillReceiveProps",args);
    }

    componentDidUpdate(...args) {
        console.log("componentDidUpdate",args);
    }

    componentWillUnmount(...args) {
        console.log("componentWillUnmount",args);
    }

    shouldComponentUpdate(...args) {
        console.log("shouldComponentUpdate",args);
       var user=prompt("true or false");
       if(user === "true")
       {
        return true;
       }
       else
       {
           return false;
       }
    }

    componentWillUpdate(...args) {
        console.log("componentWillUpdate",args);
    }

    componentDidCatch(...args) {
        console.log('componentDidCatch',args)
    }

    render(...args) {
        console.log("render",args);
        return (
            <div>
                Company Name from Child:- {this.props.companyName}
                <GrandChild companyName={this.props.companyName} />
            </div>
        )
    }
}

export default Child;