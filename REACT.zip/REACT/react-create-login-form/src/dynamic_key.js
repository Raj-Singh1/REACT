import React from 'react';

class Demo extends React.Component {
    constructor() {
        super();
        this.state = {
            ele: '',
            collect: []
        }
    }

    handleChange = (event) => {
        this.setState({
            ele: event.target.value
        });
    }

    handleClick = () => {
        var arr = this.state.collect;
        arr.push(this.state.ele);
        this.setState({
            collect: arr,
            ele: ''
        })
    }

    render() {
        var select = (<select>
            {this.state.collect.map((item, index) => { return <option key={index} value={item}>{item}</option> })}
        </select>)
        return (
            <div>
                name :
            <input type="text" value={this.state.ele} onChange={this.handleChange} />
                <br />
                <input type="submit" value="Add" onClick={this.handleClick} />
                <br />
                {select}
            </div>
        )
    }
}
export default Demo;