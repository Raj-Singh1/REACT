import React from 'react';
import './App.css';

class App extends React.Component {
  constructor(){
    super();
    this.state={
    username : '',
    pwd : '',
    collect : [],
    flag : false
    }
  }

  handleChange=(event)=>{
    if(event.target.name == "uname")
    {
    this.setState({
      username : event.target.value,
      });
    }
    else{
      this.setState({
         pwd : event.target.value
        });
    }
  }

handleCLick=(event)=>{
  var arr = this.state.collect;
  arr.push(this.state.username);
  arr.push(this.state.pwd);
  this.setState({
    collect : arr,
    pwd : '',
    flag : true
  });
}

handleSignOut=(event)=>{
  this.setState({
    username : '',
    flag : false
  });
}

render() {
    let formlogin = null;
    if(!this.state.flag)
    {
      formlogin=(
        <div>
        <h1>LOGIN PAGE</h1>
        <h3>Sign In</h3>
        <input type="text" placeholder="enter your username" name="uname" value={this.state.username} onChange={this.handleChange}/>
        <br/>
        <input type="password" placeholder="enter password" name="pwd" value={this.state.pwd} onChange={this.handleChange}/>
        <br/>
        <input type="submit" value="Login" onClick={this.handleCLick}/>
        </div>
      )
    }
    else
    {
      formlogin=(
        <div>
          <h1>LOGIN PAGE!!!</h1>
          <h3>Welcome {this.state.username}!</h3>
          <a href="#" onClick={this.handleSignOut}>SignOut</a>
        </div>
      )
    }
    return (
      <div>
        {formlogin}
      </div>
    );
  }
}

export default App;