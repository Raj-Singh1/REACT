import React from 'react';
import FormEg from './FormEg';

class ParentComponentAdd extends React.Component{
    static addNumber(num1, num2)
    {
        var sum = num1+num2;
        console.log(num1+num2);
        return sum;
        // console.log(this.props);
    }
    constructor()
    {
        super();
        this.state={};
        this.style={
            color : 'green',
        }
    }
  
    render()
    {
        return (

            <div>Static Method Example : 
                <h4 border="1" style={this.style}>HEY</h4>
                <br/>
                {ParentComponentAdd.addNumber(this.props.num1,this.props.num2)}
                <FormEg/>
            </div>
        )
    }
}

export default ParentComponentAdd;