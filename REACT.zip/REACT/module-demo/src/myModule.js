module.exports.foo=function()
{
    console.log("FOO FUNCTION CALLED");
}

// module.exports.MAGIC_NUMBER = Math