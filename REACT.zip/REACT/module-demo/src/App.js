// import React, { Component } from 'react';
// import logo from './logo.svg';
// import './App.css';

// class App extends Component {
//   render() {
//     return (

//     );
//   }
// }

// export default App;

console.log("JS LOADED");

var myModule = require("./myModule");
myModule.foo();
