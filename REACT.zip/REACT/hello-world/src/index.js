import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import background1 from "./background1.jpeg";
import background2 from "./background2.jpeg";

ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();

var userInput=prompt("enter t of f");

class Spp extends React.Component{
    render()
    {
        if(userInput.toLowerCase()=="t")
        {
            return <img src={background1}/>
        }
        else if(userInput.toLowerCase()=="f")
        {
            return <img src={background2} />
        }
    }
}
ReactDOM.render(<Spp />,document.getElementById("root"));