console.log("JS LOADED");

// var myModule = require("./myModule");
// myModule.foo();

// var EventEmitter = require("events").EventEmitter;
// var emitter = new EventEmitter();

// emitter.on("foo",function(){
//     console.log("Fog Event Called")
// });

// emitter.emit("foo");

var EventEmitter = require('events').EventEmitter,
util = require('util');

var Foo = function(){ }

util.inherits(Foo, EventEmitter);

Foo.prototype.someMethod = function() {
this.emit('customEvent', 'Data from Some Method');//this is used for caller object here caller object is Foo
}

var fooObj = new Foo();
fooObj.on('customEvent',function(arg){
console.log('Custom Event Occurred : '+arg);
});
fooObj.someMethod();
