module.exports.foo = function(){
    console.log("FOO FUNCTION CALLED");
}
